import os
import base64
import json 
from google.cloud import firestore
from google.cloud import pubsub_v1

publisher = pubsub_v1.PublisherClient()
project_id =  os.environ.get('GCP_PROJECT')

def hello_pubsub(event, context):
    """Triggered from a message on a Cloud Pub/Sub topic.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """
    pubsub_message = base64.b64decode(event['data']).decode('utf-8')
    print(pubsub_message)
    message = json.loads(pubsub_message)
    add_into_firestore(message)

def add_into_firestore(message):
    db = firestore.Client()
    doc_ref = db.collection(u'device-data').document()
    doc_ref.set(message)
